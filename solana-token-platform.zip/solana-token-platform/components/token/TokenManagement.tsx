"use client";

import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PublicKey } from '@solana/web3.js';
import { Settings, Shield, ShieldOff, Flame, Loader2, Search, AlertTriangle } from 'lucide-react';
import { tokenOperations } from '@/lib/solana/token-operations';
import { TokenInfo } from '@/types';
import { isValidPublicKey, shortenAddress } from '@/lib/solana/config';
import toast from 'react-hot-toast';

const tokenAddressSchema = z.object({
  mintAddress: z.string().min(1, 'Mint address is required').refine(isValidPublicKey, 'Invalid mint address'),
});

const burnAmountSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
});

type TokenAddressForm = z.infer<typeof tokenAddressSchema>;
type BurnAmountForm = z.infer<typeof burnAmountSchema>;

export const TokenManagement: React.FC = () => {
  const { connected, publicKey, signTransaction } = useWallet();
  const [tokenInfo, setTokenInfo] = useState<TokenInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeOperation, setActiveOperation] = useState<string | null>(null);

  const {
    register: registerAddress,
    handleSubmit: handleSubmitAddress,
    formState: { errors: addressErrors },
  } = useForm<TokenAddressForm>({
    resolver: zodResolver(tokenAddressSchema),
  });

  const {
    register: registerBurn,
    handleSubmit: handleSubmitBurn,
    formState: { errors: burnErrors },
    reset: resetBurn,
  } = useForm<BurnAmountForm>({
    resolver: zodResolver(burnAmountSchema),
  });

  const loadTokenInfo = async (data: TokenAddressForm) => {
    setIsLoading(true);
    try {
      const mint = new PublicKey(data.mintAddress);
      const info = await tokenOperations.getTokenInfo(mint);

      if (!info) {
        toast.error('Token not found or invalid mint address');
        return;
      }

      setTokenInfo(info);
      toast.success('Token loaded successfully');
    } catch (error) {
      console.error('Error loading token:', error);
      toast.error('Failed to load token information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRevokeMintAuthority = async () => {
    if (!tokenInfo || !publicKey || !signTransaction) return;

    setIsProcessing(true);
    setActiveOperation('revoke-mint');

    try {
      const mint = new PublicKey(tokenInfo.mint);
      const signature = await tokenOperations.revokeMintAuthority(
        mint,
        publicKey,
        signTransaction
      );

      toast.success('Mint authority revoked successfully!');

      // Refresh token info
      const updatedInfo = await tokenOperations.getTokenInfo(mint);
      if (updatedInfo) {
        setTokenInfo(updatedInfo);
      }
    } catch (error) {
      console.error('Error revoking mint authority:', error);
      toast.error('Failed to revoke mint authority');
    } finally {
      setIsProcessing(false);
      setActiveOperation(null);
    }
  };

  const handleRevokeFreezeAuthority = async () => {
    if (!tokenInfo || !publicKey || !signTransaction) return;

    setIsProcessing(true);
    setActiveOperation('revoke-freeze');

    try {
      const mint = new PublicKey(tokenInfo.mint);
      const signature = await tokenOperations.revokeFreezeAuthority(
        mint,
        publicKey,
        signTransaction
      );

      toast.success('Freeze authority revoked successfully!');

      // Refresh token info
      const updatedInfo = await tokenOperations.getTokenInfo(mint);
      if (updatedInfo) {
        setTokenInfo(updatedInfo);
      }
    } catch (error) {
      console.error('Error revoking freeze authority:', error);
      toast.error('Failed to revoke freeze authority');
    } finally {
      setIsProcessing(false);
      setActiveOperation(null);
    }
  };

  const handleBurnTokens = async (data: BurnAmountForm) => {
    if (!tokenInfo || !publicKey || !signTransaction) return;

    setIsProcessing(true);
    setActiveOperation('burn');

    try {
      const mint = new PublicKey(tokenInfo.mint);
      const amount = data.amount * Math.pow(10, tokenInfo.decimals);

      const signature = await tokenOperations.burnTokens(
        mint,
        publicKey,
        amount,
        signTransaction
      );

      toast.success(`${data.amount} tokens burned successfully!`);
      resetBurn();

      // Refresh token info
      const updatedInfo = await tokenOperations.getTokenInfo(mint);
      if (updatedInfo) {
        setTokenInfo(updatedInfo);
      }
    } catch (error) {
      console.error('Error burning tokens:', error);
      toast.error('Failed to burn tokens');
    } finally {
      setIsProcessing(false);
      setActiveOperation(null);
    }
  };

  if (!connected) {
    return (
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <Settings className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Connect Your Wallet</h3>
          <p className="text-gray-500">Please connect your Solana wallet to manage tokens</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Token Lookup */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <Settings className="mx-auto h-12 w-12 text-solana-purple mb-4" />
          <h2 className="text-2xl font-bold text-gray-900">Token Management</h2>
          <p className="text-gray-600 mt-2">Manage your SPL token authorities and supply</p>
        </div>

        <form onSubmit={handleSubmitAddress(loadTokenInfo)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Token Mint Address
            </label>
            <div className="flex space-x-4">
              <input
                {...registerAddress('mintAddress')}
                type="text"
                placeholder="Enter token mint address..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="bg-solana-purple text-white px-6 py-2 rounded-lg hover:bg-solana-purple/90 disabled:opacity-50 transition-colors flex items-center"
              >
                {isLoading ? (
                  <Loader2 className="animate-spin" size={16} />
                ) : (
                  <>
                    <Search size={16} className="mr-2" />
                    Load Token
                  </>
                )}
              </button>
            </div>
            {addressErrors.mintAddress && (
              <p className="text-red-500 text-sm mt-1">{addressErrors.mintAddress.message}</p>
            )}
          </div>
        </form>
      </div>

      {/* Token Information */}
      {tokenInfo && (
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Token Information</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mint Address</label>
                <p className="text-sm font-mono text-gray-900 break-all bg-gray-50 p-2 rounded">{tokenInfo.mint}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Decimals</label>
                <p className="text-gray-900">{tokenInfo.decimals}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total Supply</label>
                <p className="text-gray-900">{tokenInfo.supply}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mint Authority</label>
                <p className="text-sm font-mono text-gray-900 break-all bg-gray-50 p-2 rounded">
                  {tokenInfo.mintAuthority ? shortenAddress(tokenInfo.mintAuthority) : 'Revoked'}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Freeze Authority</label>
                <p className="text-sm font-mono text-gray-900 break-all bg-gray-50 p-2 rounded">
                  {tokenInfo.freezeAuthority ? shortenAddress(tokenInfo.freezeAuthority) : 'Revoked'}
                </p>
              </div>
            </div>
          </div>

          {/* Management Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Revoke Mint Authority */}
            <div className="border border-gray-200 rounded-lg p-6">
              <div className="text-center mb-4">
                <Shield className="mx-auto h-8 w-8 text-blue-500 mb-2" />
                <h4 className="font-semibold text-gray-900">Mint Authority</h4>
                <p className="text-sm text-gray-600">Prevent future token minting</p>
              </div>

              {tokenInfo.mintAuthority ? (
                <button
                  onClick={handleRevokeMintAuthority}
                  disabled={isProcessing && activeOperation === 'revoke-mint'}
                  className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 disabled:opacity-50 transition-colors flex items-center justify-center"
                >
                  {isProcessing && activeOperation === 'revoke-mint' ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <>
                      <ShieldOff size={16} className="mr-2" />
                      Revoke
                    </>
                  )}
                </button>
              ) : (
                <div className="text-center text-green-600 font-medium">
                  ✓ Already Revoked
                </div>
              )}
            </div>

            {/* Revoke Freeze Authority */}
            <div className="border border-gray-200 rounded-lg p-6">
              <div className="text-center mb-4">
                <Shield className="mx-auto h-8 w-8 text-purple-500 mb-2" />
                <h4 className="font-semibold text-gray-900">Freeze Authority</h4>
                <p className="text-sm text-gray-600">Required for liquidity pools</p>
              </div>

              {tokenInfo.freezeAuthority ? (
                <button
                  onClick={handleRevokeFreezeAuthority}
                  disabled={isProcessing && activeOperation === 'revoke-freeze'}
                  className="w-full bg-purple-500 text-white py-2 px-4 rounded-lg hover:bg-purple-600 disabled:opacity-50 transition-colors flex items-center justify-center"
                >
                  {isProcessing && activeOperation === 'revoke-freeze' ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <>
                      <ShieldOff size={16} className="mr-2" />
                      Revoke
                    </>
                  )}
                </button>
              ) : (
                <div className="text-center text-green-600 font-medium">
                  ✓ Already Revoked
                </div>
              )}
            </div>

            {/* Burn Tokens */}
            <div className="border border-gray-200 rounded-lg p-6">
              <div className="text-center mb-4">
                <Flame className="mx-auto h-8 w-8 text-red-500 mb-2" />
                <h4 className="font-semibold text-gray-900">Burn Tokens</h4>
                <p className="text-sm text-gray-600">Permanently reduce supply</p>
              </div>

              <form onSubmit={handleSubmitBurn(handleBurnTokens)} className="space-y-3">
                <input
                  {...registerBurn('amount', { valueAsNumber: true })}
                  type="number"
                  min="0"
                  step="any"
                  placeholder="Amount to burn"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-sm"
                />
                {burnErrors.amount && (
                  <p className="text-red-500 text-xs">{burnErrors.amount.message}</p>
                )}
                <button
                  type="submit"
                  disabled={isProcessing && activeOperation === 'burn'}
                  className="w-full bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 disabled:opacity-50 transition-colors flex items-center justify-center text-sm"
                >
                  {isProcessing && activeOperation === 'burn' ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <>
                      <Flame size={16} className="mr-2" />
                      Burn
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Warning */}
          <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-start">
              <AlertTriangle className="text-yellow-600 mr-2 flex-shrink-0" size={16} />
              <div className="text-sm text-yellow-700">
                <p className="font-medium mb-1">Important Warning:</p>
                <p>Revoking authorities and burning tokens are irreversible actions. Make sure you understand the implications before proceeding.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};