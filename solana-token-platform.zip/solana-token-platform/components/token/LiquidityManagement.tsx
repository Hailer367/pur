"use client";

import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { PublicKey } from '@solana/web3.js';
import { Droplets, Plus, Minus, Loader2, AlertCircle, Info, ExternalLink } from 'lucide-react';
import { liquidityOperations, WSOL_MINT } from '@/lib/solana/liquidity-operations';
import { isValidPublicKey } from '@/lib/solana/config';
import toast from 'react-hot-toast';

const createPoolSchema = z.object({
  tokenMint: z.string().min(1, 'Token mint address is required').refine(isValidPublicKey, 'Invalid token mint address'),
  tokenAmount: z.number().positive('Token amount must be positive'),
  solAmount: z.number().positive('SOL amount must be positive'),
});

const removePoolSchema = z.object({
  poolAddress: z.string().min(1, 'Pool address is required'),
  lpTokenAmount: z.number().positive('LP token amount must be positive'),
});

type CreatePoolForm = z.infer<typeof createPoolSchema>;
type RemovePoolForm = z.infer<typeof removePoolSchema>;

export const LiquidityManagement: React.FC = () => {
  const { connected, publicKey, signTransaction } = useWallet();
  const [isCreating, setIsCreating] = useState(false);
  const [isRemoving, setIsRemoving] = useState(false);
  const [createdPool, setCreatedPool] = useState<{ poolId: string; signature: string } | null>(null);

  const {
    register: registerCreate,
    handleSubmit: handleSubmitCreate,
    formState: { errors: createErrors },
    reset: resetCreate,
  } = useForm<CreatePoolForm>({
    resolver: zodResolver(createPoolSchema),
  });

  const {
    register: registerRemove,
    handleSubmit: handleSubmitRemove,
    formState: { errors: removeErrors },
    reset: resetRemove,
  } = useForm<RemovePoolForm>({
    resolver: zodResolver(removePoolSchema),
  });

  const handleCreatePool = async (data: CreatePoolForm) => {
    if (!connected || !publicKey || !signTransaction) {
      toast.error('Please connect your wallet first');
      return;
    }

    setIsCreating(true);

    try {
      const tokenMint = new PublicKey(data.tokenMint);

      // Check SOL balance
      const solBalance = await liquidityOperations.getSolBalance(publicKey);
      if (solBalance < data.solAmount + 0.01) { // Reserve 0.01 SOL for fees
        toast.error('Insufficient SOL balance for liquidity provision');
        return;
      }

      const result = await liquidityOperations.createLiquidityPool(
        tokenMint,
        WSOL_MINT,
        data.tokenAmount,
        data.solAmount,
        publicKey,
        signTransaction
      );

      setCreatedPool({
        poolId: result.poolId,
        signature: result.signature,
      });

      toast.success('Liquidity pool created successfully!');
      resetCreate();

    } catch (error: any) {
      console.error('Error creating liquidity pool:', error);
      if (error.message.includes('Raydium SDK')) {
        toast.error('Liquidity pool creation is not yet fully implemented. This requires integration with Raydium SDK.');
      } else {
        toast.error('Failed to create liquidity pool');
      }
    } finally {
      setIsCreating(false);
    }
  };

  const handleRemovePool = async (data: RemovePoolForm) => {
    if (!connected || !publicKey || !signTransaction) {
      toast.error('Please connect your wallet first');
      return;
    }

    setIsRemoving(true);

    try {
      const signature = await liquidityOperations.removeLiquidity(
        data.poolAddress,
        data.lpTokenAmount,
        publicKey,
        signTransaction
      );

      toast.success('Liquidity removed successfully!');
      resetRemove();

    } catch (error: any) {
      console.error('Error removing liquidity:', error);
      if (error.message.includes('Raydium SDK')) {
        toast.error('Liquidity removal is not yet fully implemented. This requires integration with Raydium SDK.');
      } else {
        toast.error('Failed to remove liquidity');
      }
    } finally {
      setIsRemoving(false);
    }
  };

  if (!connected) {
    return (
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <Droplets className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Connect Your Wallet</h3>
          <p className="text-gray-500">Please connect your Solana wallet to manage liquidity pools</p>
        </div>
      </div>
    );
  }

  if (createdPool) {
    return (
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <Droplets className="mx-auto h-16 w-16 text-blue-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Pool Created Successfully!</h2>

          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-left space-y-2">
              <div>
                <span className="font-medium text-gray-700">Pool ID:</span>
                <p className="text-sm text-gray-900 font-mono break-all">{createdPool.poolId}</p>
              </div>
              <div>
                <span className="font-medium text-gray-700">Transaction:</span>
                <p className="text-sm text-gray-900 font-mono break-all">{createdPool.signature}</p>
              </div>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setCreatedPool(null)}
              className="bg-solana-purple text-white px-6 py-2 rounded-lg hover:bg-solana-purple/90 transition-colors"
            >
              Create Another Pool
            </button>
            <a
              href={`https://dexscreener.com/solana/${createdPool.poolId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center"
            >
              <ExternalLink size={16} className="mr-2" />
              View on DexScreener
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Create Liquidity Pool */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <Plus className="mx-auto h-12 w-12 text-solana-purple mb-4" />
          <h2 className="text-2xl font-bold text-gray-900">Create Liquidity Pool</h2>
          <p className="text-gray-600 mt-2">Launch a new liquidity pool on Raydium</p>
        </div>

        {/* Important Notice */}
        <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start">
            <Info className="text-blue-600 mr-2 flex-shrink-0" size={16} />
            <div className="text-sm text-blue-700">
              <p className="font-medium mb-1">Implementation Notice:</p>
              <p>This is a demonstration interface. Full liquidity pool functionality requires integration with the Raydium SDK and additional infrastructure. The current implementation shows the UI flow but will not create actual pools.</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmitCreate(handleCreatePool)} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Token Mint Address *
            </label>
            <input
              {...registerCreate('tokenMint')}
              type="text"
              placeholder="Enter your token mint address..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
            />
            {createErrors.tokenMint && (
              <p className="text-red-500 text-sm mt-1">{createErrors.tokenMint.message}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Token Amount *
              </label>
              <input
                {...registerCreate('tokenAmount', { valueAsNumber: true })}
                type="number"
                min="0"
                step="any"
                placeholder="1000000"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
              />
              {createErrors.tokenAmount && (
                <p className="text-red-500 text-sm mt-1">{createErrors.tokenAmount.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                SOL Amount *
              </label>
              <input
                {...registerCreate('solAmount', { valueAsNumber: true })}
                type="number"
                min="0"
                step="any"
                placeholder="10"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
              />
              {createErrors.solAmount && (
                <p className="text-red-500 text-sm mt-1">{createErrors.solAmount.message}</p>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={isCreating}
            className="w-full bg-solana-purple text-white py-3 px-6 rounded-lg font-medium hover:bg-solana-purple/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
          >
            {isCreating ? (
              <>
                <Loader2 className="animate-spin mr-2" size={16} />
                Creating Pool...
              </>
            ) : (
              <>
                <Plus className="mr-2" size={16} />
                Create Liquidity Pool
              </>
            )}
          </button>
        </form>

        <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
          <div className="flex items-start">
            <AlertCircle className="text-yellow-600 mr-2 flex-shrink-0" size={16} />
            <div className="text-sm text-yellow-700">
              <p className="font-medium mb-1">Requirements:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Token must have freeze authority revoked</li>
                <li>You must own sufficient tokens and SOL</li>
                <li>Pool creation requires approximately 0.5 SOL</li>
                <li>Initial liquidity determines the starting price</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Remove Liquidity */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <Minus className="mx-auto h-12 w-12 text-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900">Remove Liquidity</h2>
          <p className="text-gray-600 mt-2">Withdraw your liquidity from existing pools</p>
        </div>

        <form onSubmit={handleSubmitRemove(handleRemovePool)} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Pool Address (AMM ID) *
            </label>
            <input
              {...registerRemove('poolAddress')}
              type="text"
              placeholder="Enter the liquidity pool address..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
            {removeErrors.poolAddress && (
              <p className="text-red-500 text-sm mt-1">{removeErrors.poolAddress.message}</p>
            )}
            <p className="text-xs text-gray-500 mt-1">
              You can find this on DexScreener as the "Pair Address"
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              LP Token Amount *
            </label>
            <input
              {...registerRemove('lpTokenAmount', { valueAsNumber: true })}
              type="number"
              min="0"
              step="any"
              placeholder="100"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
            {removeErrors.lpTokenAmount && (
              <p className="text-red-500 text-sm mt-1">{removeErrors.lpTokenAmount.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isRemoving}
            className="w-full bg-red-500 text-white py-3 px-6 rounded-lg font-medium hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
          >
            {isRemoving ? (
              <>
                <Loader2 className="animate-spin mr-2" size={16} />
                Removing Liquidity...
              </>
            ) : (
              <>
                <Minus className="mr-2" size={16} />
                Remove Liquidity
              </>
            )}
          </button>
        </form>

        <div className="mt-6 p-4 bg-red-50 rounded-lg border border-red-200">
          <div className="flex items-start">
            <AlertCircle className="text-red-600 mr-2 flex-shrink-0" size={16} />
            <div className="text-sm text-red-700">
              <p className="font-medium mb-1">Warning:</p>
              <p>Removing liquidity is permanent and you may experience impermanent loss. Make sure you understand the risks involved.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};