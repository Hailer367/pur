"use client";

import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PublicKey } from '@solana/web3.js';
import { Coins, Upload, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { tokenOperations } from '@/lib/solana/token-operations';
import { TokenMetadata } from '@/types';
import toast from 'react-hot-toast';

const tokenSchema = z.object({
  name: z.string().min(1, 'Token name is required').max(32, 'Token name too long'),
  symbol: z.string().min(1, 'Symbol is required').max(8, 'Symbol must be 8 characters or less').toUpperCase(),
  decimals: z.number().int().min(0).max(9).default(6),
  supply: z.number().positive('Supply must be positive'),
  description: z.string().max(200, 'Description too long').optional(),
});

type TokenFormData = z.infer<typeof tokenSchema>;

export const TokenCreationForm: React.FC = () => {
  const { connected, publicKey, signTransaction } = useWallet();
  const [isCreating, setIsCreating] = useState(false);
  const [createdToken, setCreatedToken] = useState<{ mint: string; signature: string } | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<TokenFormData>({
    resolver: zodResolver(tokenSchema),
    defaultValues: {
      decimals: 6,
    },
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('Image file too large. Please select a file under 5MB.');
        return;
      }

      if (!file.type.startsWith('image/')) {
        toast.error('Please select a valid image file.');
        return;
      }

      setImageFile(file);

      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: TokenFormData) => {
    if (!connected || !publicKey || !signTransaction) {
      toast.error('Please connect your wallet first');
      return;
    }

    setIsCreating(true);

    try {
      const metadata: TokenMetadata = {
        name: data.name,
        symbol: data.symbol,
        decimals: data.decimals,
        supply: data.supply,
        description: data.description || '',
        image: imagePreview || undefined,
      };

      const result = await tokenOperations.createToken(
        publicKey,
        metadata,
        signTransaction
      );

      setCreatedToken({
        mint: result.mint.toString(),
        signature: result.signature,
      });

      toast.success('Token created successfully!');

      // Reset form
      reset();
      setImageFile(null);
      setImagePreview(null);

    } catch (error) {
      console.error('Error creating token:', error);
      toast.error('Failed to create token. Please try again.');
    } finally {
      setIsCreating(false);
    }
  };

  if (!connected) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <Coins className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Connect Your Wallet</h3>
          <p className="text-gray-500">Please connect your Solana wallet to create tokens</p>
        </div>
      </div>
    );
  }

  if (createdToken) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Token Created Successfully!</h2>

          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-left space-y-2">
              <div>
                <span className="font-medium text-gray-700">Mint Address:</span>
                <p className="text-sm text-gray-900 font-mono break-all">{createdToken.mint}</p>
              </div>
              <div>
                <span className="font-medium text-gray-700">Transaction:</span>
                <p className="text-sm text-gray-900 font-mono break-all">{createdToken.signature}</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => setCreatedToken(null)}
            className="bg-solana-purple text-white px-6 py-2 rounded-lg hover:bg-solana-purple/90 transition-colors"
          >
            Create Another Token
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
      <div className="text-center mb-8">
        <Coins className="mx-auto h-12 w-12 text-solana-purple mb-4" />
        <h2 className="text-2xl font-bold text-gray-900">Create SPL Token</h2>
        <p className="text-gray-600 mt-2">Launch your custom Solana token in minutes</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Token Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Token Name *
          </label>
          <input
            {...register('name')}
            type="text"
            placeholder="My Awesome Token"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
          />
          {errors.name && (
            <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
          )}
        </div>

        {/* Token Symbol */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Symbol * (Max 8 characters)
          </label>
          <input
            {...register('symbol')}
            type="text"
            placeholder="MAT"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent uppercase"
          />
          {errors.symbol && (
            <p className="text-red-500 text-sm mt-1">{errors.symbol.message}</p>
          )}
        </div>

        {/* Decimals and Supply */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Decimals
            </label>
            <input
              {...register('decimals', { valueAsNumber: true })}
              type="number"
              min="0"
              max="9"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
            />
            {errors.decimals && (
              <p className="text-red-500 text-sm mt-1">{errors.decimals.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Total Supply *
            </label>
            <input
              {...register('supply', { valueAsNumber: true })}
              type="number"
              min="1"
              step="any"
              placeholder="1000000"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
            />
            {errors.supply && (
              <p className="text-red-500 text-sm mt-1">{errors.supply.message}</p>
            )}
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={3}
            placeholder="Brief description of your token..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-solana-purple focus:border-transparent"
          />
          {errors.description && (
            <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
          )}
        </div>

        {/* Image Upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Token Image (PNG, Max 5MB)
          </label>
          <div className="flex items-center space-x-4">
            <label className="flex items-center px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <Upload size={16} className="mr-2" />
              Choose Image
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
            {imageFile && (
              <span className="text-sm text-gray-600">{imageFile.name}</span>
            )}
          </div>
          {imagePreview && (
            <div className="mt-3">
              <img
                src={imagePreview}
                alt="Token preview"
                className="w-20 h-20 object-cover rounded-lg"
              />
            </div>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isCreating}
          className="w-full bg-solana-purple text-white py-3 px-6 rounded-lg font-medium hover:bg-solana-purple/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
        >
          {isCreating ? (
            <>
              <Loader2 className="animate-spin mr-2" size={16} />
              Creating Token...
            </>
          ) : (
            <>
              <Coins className="mr-2" size={16} />
              Create Token
            </>
          )}
        </button>
      </form>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start">
          <AlertCircle className="text-blue-500 mr-2 flex-shrink-0" size={16} />
          <div className="text-sm text-blue-700">
            <p className="font-medium mb-1">Important Notes:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Token creation requires SOL for transaction fees</li>
              <li>You will be the mint and freeze authority</li>
              <li>Consider revoking authorities for community trust</li>
              <li>All token supply will be minted to your wallet</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};