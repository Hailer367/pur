"use client";

import React from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton, WalletDisconnectButton } from '@solana/wallet-adapter-react-ui';
import { Wallet, LogOut } from 'lucide-react';
import { shortenAddress } from '@/lib/solana/config';

export const WalletConnect: React.FC = () => {
  const { connected, publicKey } = useWallet();

  if (!connected) {
    return (
      <div className="flex items-center gap-2">
        <Wallet size={20} />
        <WalletMultiButton className="!bg-solana-purple hover:!bg-solana-purple/90 !text-white !font-medium !px-4 !py-2 !rounded-lg !transition-all !duration-200" />
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 bg-green-50 text-green-700 px-3 py-2 rounded-lg border border-green-200">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <span className="font-medium">{shortenAddress(publicKey?.toString() || '')}</span>
      </div>
      <WalletDisconnectButton className="!bg-red-500 hover:!bg-red-600 !text-white !font-medium !px-3 !py-2 !rounded-lg !transition-all !duration-200 !flex !items-center !gap-2" />
    </div>
  );
};

export const WalletStatus: React.FC = () => {
  const { connected, connecting, publicKey } = useWallet();

  if (connecting) {
    return (
      <div className="flex items-center gap-2 text-amber-600">
        <div className="animate-spin rounded-full h-4 w-4 border-2 border-amber-600 border-t-transparent"></div>
        <span>Connecting wallet...</span>
      </div>
    );
  }

  if (connected && publicKey) {
    return (
      <div className="flex items-center gap-2 text-green-600">
        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
        <span>Connected: {shortenAddress(publicKey.toString())}</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 text-gray-500">
      <Wallet size={16} />
      <span>Connect wallet to continue</span>
    </div>
  );
};