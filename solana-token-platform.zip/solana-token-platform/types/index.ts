export interface TokenMetadata {
  name: string;
  symbol: string;
  decimals: number;
  supply: number;
  description: string;
  image?: string;
}

export interface TokenInfo {
  mint: string;
  name: string;
  symbol: string;
  decimals: number;
  supply: string;
  description: string;
  image?: string;
  mintAuthority?: string;
  freezeAuthority?: string;
  isRevoked?: boolean;
}

export interface LiquidityPool {
  id: string;
  baseMint: string;
  quoteMint: string;
  baseReserve: string;
  quoteReserve: string;
  lpMint: string;
  lpSupply: string;
}

export interface TransactionStatus {
  signature: string;
  confirmed: boolean;
  error?: string;
}

export interface WalletContextState {
  connected: boolean;
  publicKey: string | null;
  connecting: boolean;
  disconnect: () => void;
}

export type Network = 'mainnet-beta' | 'testnet' | 'devnet';

export interface PlatformConfig {
  network: Network;
  rpcEndpoint: string;
  commitment: 'processed' | 'confirmed' | 'finalized';
}