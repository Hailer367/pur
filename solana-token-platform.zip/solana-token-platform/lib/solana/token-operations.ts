import {
  Connection,
  PublicKey,
  Transaction,
  SystemProgram,
  Keypair,
  sendAndConfirmTransaction,
} from '@solana/web3.js';
import {
  createMint,
  createAssociatedTokenAccount,
  mintTo,
  getOrCreateAssociatedTokenAccount,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  createSetAuthorityInstruction,
  AuthorityType,
  burn,
  getAccount,
} from '@solana/spl-token';
import { TokenMetadata, TokenInfo } from '@/types';
import { connection } from './config';

export class TokenOperations {
  private connection: Connection;

  constructor(connectionInstance?: Connection) {
    this.connection = connectionInstance || connection;
  }

  /**
   * Create a new SPL token
   */
  async createToken(
    payer: PublicKey,
    metadata: TokenMetadata,
    signTransaction: (transaction: Transaction) => Promise<Transaction>
  ): Promise<{ mint: PublicKey; signature: string }> {
    try {
      // Create mint keypair
      const mintKeypair = Keypair.generate();

      // Calculate minimum balance for mint account
      const lamports = await this.connection.getMinimumBalanceForRentExemption(82);

      // Create mint account
      const transaction = new Transaction();

      transaction.add(
        SystemProgram.createAccount({
          fromPubkey: payer,
          newAccountPubkey: mintKeypair.publicKey,
          space: 82,
          lamports,
          programId: TOKEN_PROGRAM_ID,
        }),
        createMint(
          this.connection,
          payer,
          payer, // mint authority
          payer, // freeze authority
          metadata.decimals,
          mintKeypair
        )
      );

      // Sign and send transaction
      transaction.feePayer = payer;
      transaction.recentBlockhash = (await this.connection.getRecentBlockhash()).blockhash;

      const signedTransaction = await signTransaction(transaction);
      signedTransaction.partialSign(mintKeypair);

      const signature = await this.connection.sendRawTransaction(signedTransaction.serialize());
      await this.connection.confirmTransaction(signature);

      // Create associated token account and mint initial supply
      if (metadata.supply > 0) {
        await this.mintTokens(
          mintKeypair.publicKey,
          payer,
          payer,
          metadata.supply * Math.pow(10, metadata.decimals),
          signTransaction
        );
      }

      return {
        mint: mintKeypair.publicKey,
        signature,
      };
    } catch (error) {
      console.error('Error creating token:', error);
      throw error;
    }
  }

  /**
   * Mint tokens to a specific account
   */
  async mintTokens(
    mint: PublicKey,
    payer: PublicKey,
    authority: PublicKey,
    amount: number,
    signTransaction: (transaction: Transaction) => Promise<Transaction>
  ): Promise<string> {
    try {
      // Get or create associated token account
      const tokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        payer,
        mint,
        payer
      );

      // Create mint transaction
      const transaction = new Transaction().add(
        mintTo(
          mint,
          tokenAccount.address,
          authority,
          amount
        )
      );

      transaction.feePayer = payer;
      transaction.recentBlockhash = (await this.connection.getRecentBlockhash()).blockhash;

      const signedTransaction = await signTransaction(transaction);
      const signature = await this.connection.sendRawTransaction(signedTransaction.serialize());
      await this.connection.confirmTransaction(signature);

      return signature;
    } catch (error) {
      console.error('Error minting tokens:', error);
      throw error;
    }
  }

  /**
   * Revoke mint authority
   */
  async revokeMintAuthority(
    mint: PublicKey,
    currentAuthority: PublicKey,
    signTransaction: (transaction: Transaction) => Promise<Transaction>
  ): Promise<string> {
    try {
      const transaction = new Transaction().add(
        createSetAuthorityInstruction(
          mint,
          currentAuthority,
          AuthorityType.MintTokens,
          null // Setting to null revokes the authority
        )
      );

      transaction.feePayer = currentAuthority;
      transaction.recentBlockhash = (await this.connection.getRecentBlockhash()).blockhash;

      const signedTransaction = await signTransaction(transaction);
      const signature = await this.connection.sendRawTransaction(signedTransaction.serialize());
      await this.connection.confirmTransaction(signature);

      return signature;
    } catch (error) {
      console.error('Error revoking mint authority:', error);
      throw error;
    }
  }

  /**
   * Revoke freeze authority
   */
  async revokeFreezeAuthority(
    mint: PublicKey,
    currentAuthority: PublicKey,
    signTransaction: (transaction: Transaction) => Promise<Transaction>
  ): Promise<string> {
    try {
      const transaction = new Transaction().add(
        createSetAuthorityInstruction(
          mint,
          currentAuthority,
          AuthorityType.FreezeAccount,
          null // Setting to null revokes the authority
        )
      );

      transaction.feePayer = currentAuthority;
      transaction.recentBlockhash = (await this.connection.getRecentBlockhash()).blockhash;

      const signedTransaction = await signTransaction(transaction);
      const signature = await this.connection.sendRawTransaction(signedTransaction.serialize());
      await this.connection.confirmTransaction(signature);

      return signature;
    } catch (error) {
      console.error('Error revoking freeze authority:', error);
      throw error;
    }
  }

  /**
   * Burn tokens
   */
  async burnTokens(
    mint: PublicKey,
    owner: PublicKey,
    amount: number,
    signTransaction: (transaction: Transaction) => Promise<Transaction>
  ): Promise<string> {
    try {
      // Get associated token account
      const tokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        owner,
        mint,
        owner
      );

      const transaction = new Transaction().add(
        burn(
          tokenAccount.address,
          mint,
          owner,
          amount
        )
      );

      transaction.feePayer = owner;
      transaction.recentBlockhash = (await this.connection.getRecentBlockhash()).blockhash;

      const signedTransaction = await signTransaction(transaction);
      const signature = await this.connection.sendRawTransaction(signedTransaction.serialize());
      await this.connection.confirmTransaction(signature);

      return signature;
    } catch (error) {
      console.error('Error burning tokens:', error);
      throw error;
    }
  }

  /**
   * Get token information
   */
  async getTokenInfo(mint: PublicKey): Promise<TokenInfo | null> {
    try {
      const mintInfo = await this.connection.getParsedAccountInfo(mint);

      if (!mintInfo.value || !mintInfo.value.data) {
        return null;
      }

      const data = mintInfo.value.data as any;

      return {
        mint: mint.toString(),
        name: '', // This would come from metadata in a real implementation
        symbol: '', // This would come from metadata in a real implementation
        decimals: data.parsed.info.decimals,
        supply: data.parsed.info.supply,
        description: '',
        mintAuthority: data.parsed.info.mintAuthority,
        freezeAuthority: data.parsed.info.freezeAuthority,
        isRevoked: !data.parsed.info.mintAuthority && !data.parsed.info.freezeAuthority,
      };
    } catch (error) {
      console.error('Error getting token info:', error);
      return null;
    }
  }
}

export const tokenOperations = new TokenOperations();