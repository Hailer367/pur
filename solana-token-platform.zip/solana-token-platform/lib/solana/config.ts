import { Connection, clusterApiUrl, PublicKey } from '@solana/web3.js';
import { Network, PlatformConfig } from '@/types';

// Default configuration
export const DEFAULT_NETWORK: Network = 'devnet';
export const DEFAULT_COMMITMENT = 'confirmed';

// RPC endpoints
export const RPC_ENDPOINTS = {
  'mainnet-beta': process.env.NEXT_PUBLIC_RPC_ENDPOINT || 'https://api.mainnet-beta.solana.com',
  'testnet': clusterApiUrl('testnet'),
  'devnet': clusterApiUrl('devnet'),
};

// Platform configuration
export const config: PlatformConfig = {
  network: (process.env.NEXT_PUBLIC_SOLANA_NETWORK as Network) || DEFAULT_NETWORK,
  rpcEndpoint: RPC_ENDPOINTS[DEFAULT_NETWORK],
  commitment: DEFAULT_COMMITMENT,
};

// Create connection instance
export const connection = new Connection(
  config.rpcEndpoint,
  config.commitment
);

// Common addresses
export const TOKEN_PROGRAM_ID = new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
export const ASSOCIATED_TOKEN_PROGRAM_ID = new PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
export const SYSTEM_PROGRAM_ID = new PublicKey('11111111111111111111111111111112');

// Utility functions
export const shortenAddress = (address: string, chars = 4): string => {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
};

export const formatTokenAmount = (amount: number, decimals: number = 6): string => {
  return (amount / Math.pow(10, decimals)).toLocaleString();
};

export const parseTokenAmount = (amount: string, decimals: number = 6): number => {
  return parseFloat(amount) * Math.pow(10, decimals);
};

export const isValidPublicKey = (address: string): boolean => {
  try {
    new PublicKey(address);
    return true;
  } catch {
    return false;
  }
};