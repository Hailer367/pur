"use client";

import React from 'react';
import Link from 'next/link';
import { Navigation } from '@/components/Navigation';
import { WalletStatus } from '@/components/wallet/WalletConnect';
import { Coins, Settings, Droplets, ArrowRight, Zap, Shield, DollarSign } from 'lucide-react';

const features = [
  {
    icon: Coins,
    title: 'Create SPL Tokens',
    description: 'Launch your custom Solana tokens in minutes with our intuitive interface.',
    href: '/create-token',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
  },
  {
    icon: Settings,
    title: 'Manage Authorities',
    description: 'Revoke mint and freeze authorities, burn tokens, and manage your token lifecycle.',
    href: '/manage-token',
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
  },
  {
    icon: Droplets,
    title: 'Liquidity Pools',
    description: 'Create and manage liquidity pools on Raydium for seamless trading.',
    href: '/liquidity',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
];

const benefits = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Deploy tokens in seconds on Solana\'s high-performance blockchain',
  },
  {
    icon: Shield,
    title: 'Secure & Trusted',
    description: 'Built with industry-standard security practices and thorough testing',
  },
  {
    icon: DollarSign,
    title: 'Cost Effective',
    description: 'Low transaction fees make token creation affordable for everyone',
  },
];

export default function HomePage() {
  return (
    <div>
      <Navigation />

      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
            <div className="text-center">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Create Solana Tokens
                <span className="block text-solana-purple">Without Code</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Launch, manage, and scale your SPL tokens on Solana with our powerful no-code platform. 
                From creation to liquidity pools, we\'ve got you covered.
              </p>

              {/* Wallet Status */}
              <div className="mb-8">
                <WalletStatus />
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link
                  href="/create-token"
                  className="bg-solana-purple text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-solana-purple/90 transition-colors flex items-center group"
                >
                  Get Started
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                </Link>
                <Link
                  href="/manage-token"
                  className="border border-gray-300 text-gray-700 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-colors"
                >
                  Manage Existing Token
                </Link>
              </div>
            </div>
          </div>

          {/* Background decoration */}
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-gradient-to-br from-solana-purple/20 to-solana-blue/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-gradient-to-tr from-solana-green/20 to-solana-purple/20 rounded-full blur-3xl"></div>
        </section>

        {/* Features Section */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Everything You Need
              </h2>
              <p className="text-xl text-gray-600">
                Comprehensive tools for the complete token lifecycle
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature) => (
                <Link
                  key={feature.title}
                  href={feature.href}
                  className="group bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-8 border border-gray-100 hover:border-gray-200"
                >
                  <div className={`inline-flex p-3 rounded-lg ${feature.bgColor} mb-4`}>
                    <feature.icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-solana-purple transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{feature.description}</p>
                  <div className="flex items-center text-solana-purple font-medium group-hover:translate-x-1 transition-transform">
                    Learn more
                    <ArrowRight className="ml-1" size={16} />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Why Choose SolToken?
              </h2>
              <p className="text-xl text-gray-600">
                Built for the next generation of token creators
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {benefits.map((benefit) => (
                <div key={benefit.title} className="text-center">
                  <div className="inline-flex p-4 rounded-full bg-solana-purple/10 mb-4">
                    <benefit.icon className="h-8 w-8 text-solana-purple" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-gradient-to-r from-solana-purple to-solana-blue">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Launch Your Token?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Join thousands of creators who trust SolToken for their token needs
            </p>
            <Link
              href="/create-token"
              className="inline-flex items-center bg-white text-solana-purple px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors group"
            >
              Create Your First Token
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-solana-purple to-solana-blue rounded-lg flex items-center justify-center">
                <Coins className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">SolToken</span>
            </div>
            <p className="text-gray-400 mb-4">
              The no-code platform for Solana token creation and management
            </p>
            <p className="text-gray-500 text-sm">
              Built with ♥ for the Solana ecosystem
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}