import { Navigation } from '@/components/Navigation';
import { LiquidityManagement } from '@/components/token/LiquidityManagement';

export default function LiquidityPage() {
  return (
    <div>
      <Navigation />
      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <LiquidityManagement />
        </div>
      </main>
    </div>
  );
}