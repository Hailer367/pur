import { Navigation } from '@/components/Navigation';
import { TokenManagement } from '@/components/token/TokenManagement';

export default function ManageTokenPage() {
  return (
    <div>
      <Navigation />
      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <TokenManagement />
        </div>
      </main>
    </div>
  );
}