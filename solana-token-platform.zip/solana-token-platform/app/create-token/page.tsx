import { Navigation } from '@/components/Navigation';
import { TokenCreationForm } from '@/components/token/TokenCreationForm';

export default function CreateTokenPage() {
  return (
    <div>
      <Navigation />
      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <TokenCreationForm />
        </div>
      </main>
    </div>
  );
}