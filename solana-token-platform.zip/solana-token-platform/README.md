# Solana Token Platform

A complete no-code platform for creating and managing Solana SPL tokens with integrated liquidity pool functionality. Built with Next.js 14, TypeScript, and Tailwind CSS.

![Platform Preview](https://via.placeholder.com/800x400/9945FF/white?text=Solana+Token+Platform)

## 🚀 Features

### Core Functionality
- **SPL Token Creation**: Launch custom tokens with name, symbol, decimals, supply, description, and image
- **Authority Management**: Revoke mint and freeze authorities for community trust
- **Token Burning**: Permanently reduce token supply
- **Wallet Integration**: Support for Phantom and Solflare wallets
- **Liquidity Pools**: Create and remove liquidity pools (framework ready)

### Technical Features
- **Next.js 14**: Latest React framework with App Router
- **TypeScript**: Full type safety throughout the application
- **Tailwind CSS**: Modern, responsive UI design
- **Solana Web3.js**: Official Solana JavaScript SDK
- **SPL Token**: Native Solana token program integration
- **Wallet Adapters**: Seamless wallet connection experience
- **Form Validation**: Zod schema validation with react-hook-form
- **Toast Notifications**: User-friendly feedback system

## 🛠️ Tech Stack

- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS
- **Blockchain**: Solana Web3.js, SPL Token
- **Wallets**: Solana Wallet Adapter (Phantom, Solflare)
- **Forms**: React Hook Form with Zod validation
- **UI Components**: Custom components with Lucide React icons
- **Notifications**: React Hot Toast
- **Animations**: Framer Motion

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd solana-token-platform
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env.local
   ```

   Edit `.env.local`:
   ```env
   NEXT_PUBLIC_SOLANA_NETWORK=devnet
   NEXT_PUBLIC_RPC_ENDPOINT=https://api.devnet.solana.com
   ```

4. **Run the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

5. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NEXT_PUBLIC_SOLANA_NETWORK` | Solana network (mainnet-beta, testnet, devnet) | `devnet` |
| `NEXT_PUBLIC_RPC_ENDPOINT` | Custom RPC endpoint (optional) | Network default |

### Network Configuration

For **development**:
```env
NEXT_PUBLIC_SOLANA_NETWORK=devnet
NEXT_PUBLIC_RPC_ENDPOINT=https://api.devnet.solana.com
```

For **production**:
```env
NEXT_PUBLIC_SOLANA_NETWORK=mainnet-beta
NEXT_PUBLIC_RPC_ENDPOINT=https://api.mainnet-beta.solana.com
```

### Premium RPC Providers

For better performance, consider using premium RPC providers:
- **Alchemy**: `https://solana-mainnet.g.alchemy.com/v2/YOUR_KEY`
- **Ankr**: `https://rpc.ankr.com/solana`
- **QuickNode**: `https://your-endpoint.solana.quiknode.pro/`

## 🚀 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Add environment variables in the Vercel dashboard

3. **Environment Variables in Vercel**
   ```
   NEXT_PUBLIC_SOLANA_NETWORK = mainnet-beta
   NEXT_PUBLIC_RPC_ENDPOINT = https://api.mainnet-beta.solana.com
   ```

4. **Deploy**
   Vercel will automatically deploy your application

### Manual Deployment

```bash
# Build the application
npm run build

# Start the production server
npm start
```

## 📖 Usage Guide

### 1. Connect Wallet
- Click "Connect Wallet" in the navigation
- Select your preferred wallet (Phantom or Solflare)
- Approve the connection

### 2. Create Token
- Navigate to "Create Token"
- Fill in token details:
  - **Name**: Your token's full name
  - **Symbol**: Short ticker (max 8 characters)
  - **Decimals**: Precision level (recommended: 6)
  - **Supply**: Total number of tokens
  - **Description**: Brief description
  - **Image**: Token logo (optional)
- Click "Create Token"
- Sign the transaction in your wallet

### 3. Manage Token
- Navigate to "Manage Tokens"
- Enter your token's mint address
- Available actions:
  - **Revoke Mint Authority**: Prevent future minting
  - **Revoke Freeze Authority**: Required for liquidity pools
  - **Burn Tokens**: Reduce total supply

### 4. Liquidity Pools
- Navigate to "Liquidity"
- Create or remove liquidity pools
- Note: Full Raydium SDK integration required for production

## 🏗️ Project Structure

```
solana-token-platform/
├── app/                          # Next.js App Router
│   ├── create-token/            # Token creation page
│   ├── manage-token/            # Token management page
│   ├── liquidity/               # Liquidity pools page
│   ├── globals.css              # Global styles
│   ├── layout.tsx               # Root layout
│   └── page.tsx                 # Home page
├── components/                   # React components
│   ├── Navigation.tsx           # Main navigation
│   ├── token/                   # Token-related components
│   ├── ui/                      # UI components
│   └── wallet/                  # Wallet components
├── lib/                         # Library functions
│   └── solana/                  # Solana utilities
├── types/                       # TypeScript types
├── utils/                       # Utility functions
├── hooks/                       # Custom React hooks
└── public/                      # Static assets
```

## 🔐 Security Considerations

1. **Environment Variables**: Never expose private keys in environment variables
2. **RPC Endpoints**: Use secure, rate-limited RPC endpoints for production
3. **Wallet Security**: Always verify transactions before signing
4. **Authority Management**: Consider implications before revoking authorities
5. **Smart Contract Audits**: Audit any custom smart contracts

## 🧪 Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint
- `npm run type-check` - Run TypeScript type checking

### Adding New Features

1. **Create Components**: Add new components in the `components/` directory
2. **Add Routes**: Create new pages in the `app/` directory
3. **Extend Types**: Update TypeScript types in the `types/` directory
4. **Update Navigation**: Add new routes to the navigation component

## 🐛 Troubleshooting

### Common Issues

1. **Wallet Connection Fails**
   - Ensure you have a Solana wallet installed
   - Check that the wallet is on the correct network
   - Clear browser cache and try again

2. **Transaction Fails**
   - Check your SOL balance for transaction fees
   - Verify RPC endpoint is responding
   - Ensure wallet is connected to the correct network

3. **Build Errors**
   - Run `npm install` to ensure all dependencies are installed
   - Check TypeScript errors with `npm run type-check`
   - Verify environment variables are set correctly

### Getting Help

- Check the [Solana Documentation](https://docs.solana.com/)
- Review [SPL Token Documentation](https://spl.solana.com/token)
- Join the [Solana Discord](https://discord.gg/solana)

## 🚧 Limitations

1. **Liquidity Pools**: Current implementation shows UI framework only. Full Raydium SDK integration required for production use.
2. **Metadata**: Token metadata is stored locally. Consider using Metaplex for decentralized metadata.
3. **Token Standards**: Currently supports basic SPL tokens. Token extensions (Token-2022) not implemented.

## 🛣️ Roadmap

- [ ] Full Raydium SDK integration for liquidity pools
- [ ] Metaplex metadata integration
- [ ] Token-2022 program support
- [ ] Multi-signature wallet support
- [ ] Advanced token features (transfer fees, etc.)
- [ ] Analytics dashboard
- [ ] Batch operations
- [ ] Mobile app

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

Contributions are welcome! Please read the [CONTRIBUTING](CONTRIBUTING.md) guide for details on our code of conduct and the process for submitting pull requests.

## ⭐ Acknowledgments

- [Solana](https://solana.com/) for the amazing blockchain platform
- [Solana Labs](https://github.com/solana-labs) for the official SDKs
- [Metaplex](https://metaplex.com/) for NFT and metadata standards
- [Raydium](https://raydium.io/) for DEX infrastructure
- [Vercel](https://vercel.com/) for deployment platform

---

**Built with ❤️ for the Solana ecosystem**

For questions or support, please open an issue or join our community discussions.